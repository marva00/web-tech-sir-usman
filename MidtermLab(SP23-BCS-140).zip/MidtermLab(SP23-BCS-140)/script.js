document.addEventListener('DOMContentLoaded', function() {
    const viewMoreBtn = document.getElementById('view-more-btn');

    // Initial check to hide button if there are no hidden testimonials
    if (document.querySelectorAll('.testimonial-item.hidden').length === 0) {
        if (viewMoreBtn) viewMoreBtn.style.display = 'none';
        return; // Exit the script
    }

    viewMoreBtn.addEventListener('click', function() {
        // Find all testimonials that are currently hidden
        const hiddenTestimonials = document.querySelectorAll('.testimonial-item.hidden');
        
        // Convert the NodeList to an Array and take the first 2 items
        const testimonialsToShow = Array.from(hiddenTestimonials).slice(0, 2);

        // Remove the 'hidden' class from this batch of 2
        testimonialsToShow.forEach(function(testimonial) {
            testimonial.classList.remove('hidden');
        });

        // After revealing, check again if there are any more hidden testimonials
        if (document.querySelectorAll('.testimonial-item.hidden').length === 0) {
            // If none are left, hide the button
            viewMoreBtn.style.display = 'none';
        }
    });
});